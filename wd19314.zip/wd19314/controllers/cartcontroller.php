<?php
class CartController {
    //Thêm sp vào giỏ hàng
    public function addToCart() {
        $carts = $_SESSION['cart'] ?? [];

        //Lấy id sản phẩm thêm vaodf giỏ hàng
        $id = $_GET['id'];
        //Lấy sản phẩm theo id
        $product = ( new Product)->find($id);
        //Kiểm tra xem giỏ hàng có sp đó chưa
        if (isset($carts[$id])) {
            //Tăng số lượng lên
            $carts[$id]['quantity'] += 1;
        } else {
            $carts[$id] = [
                'name'      => $product['name'],
                'image'     => $product['image'],
                'price'     => $product['price'],
                'quantity'  => 1
            ];
        }
        //Gán lại giỏ hàng cho session
        $_SESSION['cart'] = $carts;

        //Tính tổng số lượng
        $_SESSION['totalQuantity'] = $this->totalQuantityInCart();

        //Lấy lại URI trc đó
        $uri = $_SESSION['URI'];

        return header("Location: " . $uri);
    }
    //Tính tổng số lượng sp
    public function totalQuantityInCart() {
        $carts = $_SESSION['cart'] ?? [];
        $total = 0;
        foreach ($carts as $cart) {
            $total += $cart['quantity'];
        }
        return $total;
    }

    //Tính tổng giá trong giỏ hàng
    public function totalPriceInCart() {
        $carts = $_SESSION['cart'] ?? [];
        $total = 0;
        foreach ($carts as $cart) {
            $total += $cart['price'] * $cart['quantity'];
        }
        return $total;
    }

    //Hàm hiển thị chi tiết sản phẩm giỏ hàng
    public function viewcart() {
        $carts = $_SESSION['cart'] ?? [];

        $categories = (new Category) -> all();

        $totalPrice = $this->totalPriceInCart();

        return view('clients.carts.cart', compact('carts', 'categories', 'totalPrice'));

    }

    //Xóa sản phẩm trong giỏ hàng
    public function deleteProductInCart() {
        $id = $_GET['id'];
        unset($_SESSION['cart'][$id]);

        //Tính tổng số lượng
        $_SESSION['totalQuantity'] = $this->totalQuantityInCart();
        return header("location: " . ROOT_URL . "?ctl=view-cart");
    }

    //Cập nhật giỏ hàng
    public function updateCart() {
        $quantities = $_POST['quantity'];
        foreach ($quantities as $id => $qty) {
            $_SESSION['cart'][$id]['quantity'] = $qty;
        }
        return header("Location: " . ROOT_URL . "?ctl=view-cart");
    }
}
?>