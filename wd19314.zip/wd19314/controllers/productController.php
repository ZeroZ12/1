<?php
class ProductController{
    public function index(){
        $id = $_GET['id'];
        $products = (new Product)->listProductInCategory($id);

        $title = $products[0]['cate_name'] ?? '';

        $categories = (new Category)->all();

        return view(
            'clients.category.category',
            compact('products','categories','title')
        );
    } 
    public function show() {
        $id = $_GET['id'];

        $product = (new Product)->find($id);

        $categories = (new Category)->all();

        $title = $product['name'] ?? "";

        //Lưu thông tin uri
        $_SESSION['URI'] = $_SERVER['REQUEST_URI'];

        return view(
            'clients.product.detal',
            compact('product','categories','title')
    );
    }
}
?>