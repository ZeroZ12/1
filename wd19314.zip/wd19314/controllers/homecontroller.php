<?php

class HomeController {
    public function index(){
        //lấy các sản phẩm thú cưng
        $pets = (new Product)->listProductInpet();
        //lấy các sản phẩm không phải thú cưng
        $products = (new Product)->listProductOtherPet();
        //lấy danh mục
        $categories = (new Category)->all();

        return view("clients.home", compact('pets','products','categories'));
    }
}