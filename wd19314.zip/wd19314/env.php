<?php

//Đường dẫn thư mục gốc
const ROOT_DIR  = __DIR__ . "/";

//Đường dẫn website gốc
const ROOT_URL  = "http://localhost/wd19314/";

//Đường dẫn đến admin
const ADMIN_URL = ROOT_URL . "admin/";