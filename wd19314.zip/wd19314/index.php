<?php
session_start();
require_once __DIR__ . "/env.php";
require_once __DIR__ . "/common/function.php";
require_once __DIR__ . "/models/BaseModel.php";
require_once __DIR__ . "/models/Category.php";
require_once __DIR__ . "/models/Product.php";

require_once __DIR__ . "/controllers/homecontroller.php";
require_once __DIR__ . "/controllers/productController.php";
require_once __DIR__ . "/controllers/cartcontroller.php";


$ctl = $_GET['ctl'] ?? '';


match ($ctl) {
    '', 'home' => (new HomeController)->index(),
    'category' =>  (new ProductController)->index(),
    'detail' => (new ProductController)->show(),
    'add-cart' => (new CartController)->addToCart(),
    'view-cart' => (new CartController)->viewcart(),
    'delete-cart' => (new CartController)->deleteProductInCart(),
    'update-cart' => (new CartController)->updateCart(),
    default => view('errors.404'),
};

/*
1. Trinh hải Long
2. Nguyễn Trung Đức
3. Phan Xuân Đức
*/