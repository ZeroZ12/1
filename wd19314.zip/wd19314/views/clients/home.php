<?php 
include_once ROOT_DIR . "views/clients/header.php"
?>

<div class="container mt-5">
    <h2>Thú cưng</h2>
        <div class="row g-4">
            <?php foreach($pets as $pet) : ?>
            <!-- Box Sản Phẩm -->
            <div class="col-md-3">
                <div class="product-box">
                    <img src="<?= $pet['image']?>" alt="Product Image" class="product-img">
                    <div class="product-info">
                        <a href="<?= ROOT_URL . '?ctl=detail&id=' . $pet['id'] ?>">
                            <h5 class="product-name"><?= $pet['name']?></h5>
                        </a>
                        <div>
                            <span class="product-price"><?= $pet['price']?></span>
                        </div>
                        <div class="product-buttons">

                            <button class="btn btn-outline-success">Thêm vào giỏ hàng</button>
                        </div>
                    </div>
                </div>
            </div>
           <?php endforeach ?>
        </div>
        <h2 class="mt-5">Sản phẩm dành cho thú cưng</h2>
        <div class="row g-4">
        <?php foreach($products as $product) : ?>
            <!-- Box Sản Phẩm -->
            <div class="col-md-3">
                <div class="product-box">
                    <img src="<?= $product['image']?>" alt="Product Image" class="product-img">
                    <div class="product-info">
                        <a href="<?= ROOT_URL . '?ctl=detail&id=' . $product['id'] ?>">
                            <h5 class="product-name"><?= $product['name']?></h5>
                        </a>
                        <div>
                            <span class="product-price"><?= $product['price']?></span>
                        </div>
                        <div class="product-buttons">

                            <button class="btn btn-outline-success">Thêm vào giỏ hàng</button>
                        </div>
                    </div>
                </div>
            </div>
           <?php endforeach ?>
        </div>
        
    </div>

<?php 
include_once ROOT_DIR . "views/clients/footer.php"
?>