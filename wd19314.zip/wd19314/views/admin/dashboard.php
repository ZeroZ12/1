<?php include_once ROOT_DIR . "views/admin/header.php" ?>

<h1>Trang Dashboard</h1>

<?php include_once ROOT_DIR . "views/admin/footer.php" ?>